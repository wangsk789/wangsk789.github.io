<?php

	header("Content-Type: application/json");
	$file = "database.json";

	if ($_SERVER['REQUEST_METHOD'] != "POST" || !isset($_REQUEST['tag'])) {
		die("BadRequest");
	}

	if (isset($_REQUEST['value'])){
		
		$tag = trim($_REQUEST['tag']);
		$value = trim($_REQUEST['value']);

		$f = fopen($file, 'r');
		$data = fgets($f);
		fclose($f);

		$parsedData = json_decode($data, true);
		$parsedData[$tag] = $value;

		$f = fopen($file, 'w') or die("Can't open file");
		fwrite($f, json_encode($parsedData));
		fclose($f);

		$result = array("STORED", $tag, $value);
		echo json_encode($result);
		
	}else{

		$tag = trim($_REQUEST['tag']);

		$f = fopen($file, 'r');
		$data = json_decode(fgets($f), true);
		fclose($f);
		
		if(isset($data[$tag])){
			$result = array("VALUE", $tag, $data[$tag]);
		}else{
			$result = array("VALUE", $tag, "");
		}
		echo json_encode($result);
		
	}
?>
